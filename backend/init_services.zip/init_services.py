#!/usr/bin/env python3
"""
Lambda function to initialize services in the database
"""
import json
import boto3
import os
import pg8000.native
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """Initialize services in the database"""
    
    try:
        # Get database connection using secrets manager
        db_secret_arn = os.environ.get('DB_SECRET_ARN', 'arn:aws:secretsmanager:us-west-2:588738589514:secret:edgar/rds/master-credentials-0K6opS')
        
        # Get database credentials from Secrets Manager
        secrets_client = boto3.client('secretsmanager')
        secret_response = secrets_client.get_secret_value(SecretId=db_secret_arn)
        secret = json.loads(secret_response['SecretString'])
        
        # Connect to database
        conn = pg8000.native.Connection(
            user=secret['username'],
            password=secret['password'],
            host=secret['host'],
            port=secret['port'],
            database=secret['dbname'],
            ssl_context=True
        )
        
        logger.info("Database connection established")
        
        # Check if services already exist
        results = conn.run("SELECT COUNT(*) FROM services")
        service_count = results[0][0]
        logger.info(f"Current services count: {service_count}")
        
        if service_count == 0:
            # Insert default services
            conn.run("""
                INSERT INTO services (name, description, duration_minutes, base_price) 
                VALUES 
                    ('Oil Change', 'Standard oil change with filter', 30, 45.00),
                    ('Brake Inspection', 'Complete brake system inspection', 45, 65.00),
                    ('Battery Replacement', 'Replace car battery', 20, 120.00),
                    ('Tire Rotation', 'Rotate and balance tires', 45, 50.00)
            """)
            logger.info("✅ Services inserted successfully")
        else:
            logger.info("ℹ️ Services already exist, skipping insertion")
        
        # Verify services
        results = conn.run("SELECT name FROM services ORDER BY name")
        services = [row[0] for row in results]
        logger.info(f"Available services: {services}")
        
        conn.close()
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Services initialized successfully',
                'services': services,
                'count': len(services)
            })
        }
        
    except Exception as e:
        logger.error(f"Failed to initialize services: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
