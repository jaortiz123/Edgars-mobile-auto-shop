import json
import os
import boto3
from decimal import Decimal
import datetime
import traceback

# Initialize clients outside the handler for performance and connection reuse.
ddb = boto3.resource('dynamodb')
table_name = os.environ.get('QUOTES_TABLE', 'EdgarQuotes')
table = ddb.Table(table_name)

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))
    try:
        # --- 1. Parse Input ---
        try:
            body = json.loads(event.get("body", "{}"))
            print("Parsed body:", body)
        except Exception as e:
            print("JSON decode error:", str(e))
            body = {}

        # Normalize service type for robust lookup
        service_type_input = body.get("service", "Unknown")
        print("service_type_input:", service_type_input)
        service_type_key = service_type_input.strip().lower()
        print("service_type_key:", service_type_key)

        # Lowercase keys for robust matching
        price_lookup = {
            "oil change": Decimal("50"),
            "brake repair": Decimal("200"),
            "battery": Decimal("120"),
            "engine": Decimal("300")
        }
        quote_price = price_lookup.get(service_type_key, Decimal("100"))
        print("quote_price:", quote_price)
        # For response, use title case for display
        service_type_display = service_type_key.title() if service_type_key != "unknown" else "Unknown"
        print("service_type_display:", service_type_display)

        # --- 2. Apply Logic ---

        # --- 3. Persist Structured Data ---
        request_id = getattr(context, 'aws_request_id', 'NO_CONTEXT_ID')
        timestamp = datetime.datetime.utcnow().isoformat() + "Z"

        item_to_store = {
            'RequestID': request_id,
            'ServiceType': service_type_display,
            'QuotePrice': str(quote_price),  # Store as string for DynamoDB compatibility
            'Timestamp': timestamp
        }
        print("item_to_store:", item_to_store)

        try:
            table.put_item(Item=item_to_store)
            print(f"Successfully stored quote {request_id} in DynamoDB.")
        except Exception as e:
            print(f"Error writing to DynamoDB: {e}")
            traceback.print_exc()

        # --- 4. Respond Dynamically ---
        response_payload = {
            "quote": f"Estimated cost for {service_type_display} is ${quote_price}",
            "requestId": request_id
        }
        print("Returning response:", response_payload)
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(response_payload)
        }

    except Exception as e:
        print("Unhandled exception in Lambda:", str(e))
        traceback.print_exc()
        error_payload = {"error": str(e), "trace": traceback.format_exc()}
        print("Returning error response:", error_payload)
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(error_payload)
        }
